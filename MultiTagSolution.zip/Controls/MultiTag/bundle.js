var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./MultiTag/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./MultiTag/index.ts":
/*!***************************!*\
  !*** ./MultiTag/index.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar MultiTag =\n/** @class */\nfunction () {\n  function MultiTag() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  MultiTag.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged; // @ts-ignore         \n\n    this._tagValueFieldName = this._context.parameters.TagValue.attributes.LogicalName; // @ts-ignore \n\n    this._currentValues = Xrm.Page.getAttribute(this._tagValueFieldName).getValue();\n    this._containerBox = document.createElement(\"div\");\n\n    this._containerBox.setAttribute(\"class\", \"container\");\n\n    this._innerContainer = document.createElement(\"div\");\n\n    this._innerContainer.setAttribute(\"class\", \"innerDiv\");\n\n    this._inputElement = document.createElement(\"input\");\n\n    this._inputElement.setAttribute(\"id\", \"inputTag\");\n\n    this._inputElement.setAttribute(\"type\", \"text\");\n\n    this._inputElement.addEventListener(\"keypress\", this.onKeyPress.bind(this));\n\n    if (!this._currentValues) {\n      this._taggedValues = [];\n\n      this._innerContainer.classList.add(\"hideBlock\");\n    } else {\n      this._innerContainer.classList.add(\"displayBlock\");\n\n      this._taggedValues = this._currentValues.split(\", \");\n      this.loadTags();\n    }\n\n    this._containerBox.appendChild(this._innerContainer);\n\n    this._containerBox.appendChild(this._inputElement);\n\n    container.appendChild(this._containerBox);\n  };\n  /**\r\n   * Display the existing values as Tags on load of form\r\n   */\n\n\n  MultiTag.prototype.loadTags = function () {\n    for (var i = 0; i < this._taggedValues.length; i++) {\n      this._tagElement = document.createElement(\"div\");\n\n      this._tagElement.setAttribute(\"class\", \"customTag\");\n\n      this._tagContent = document.createElement(\"div\");\n      this._tagContent.innerHTML = this._taggedValues[i];\n      this._tagClose = document.createElement(\"a\");\n      this._tagClose.innerHTML = \"X\";\n\n      this._tagClose.addEventListener(\"click\", this.onClickOfClose.bind(this));\n\n      this._tagClose.setAttribute(\"class\", \"closeTag\");\n\n      this._tagElement.append(this._tagContent);\n\n      this._tagElement.appendChild(this._tagClose);\n\n      this._innerContainer.appendChild(this._tagElement);\n    }\n  };\n  /**\r\n   * Function called On key press\r\n   */\n\n\n  MultiTag.prototype.onKeyPress = function (e) {\n    if (e.key == \"Enter\") {\n      if (this._inputElement.value) {\n        if (!this._innerContainer.classList.contains(\"displayBlock\") && this._innerContainer.classList.contains(\"hideBlock\")) {\n          this._innerContainer.classList.add(\"displayBlock\");\n\n          this._innerContainer.classList.remove(\"hideBlock\");\n        }\n\n        this._taggedValues.push(this._inputElement.value);\n\n        this._tagElement = document.createElement(\"div\");\n\n        this._tagElement.setAttribute(\"class\", \"customTag\");\n\n        this._tagContent = document.createElement(\"div\");\n\n        this._tagContent.setAttribute(\"class\", \"tagContent\");\n\n        this._tagContent.innerHTML = this._inputElement.value;\n        this._tagClose = document.createElement(\"a\");\n        this._tagClose.innerHTML = \"X\";\n\n        this._tagClose.addEventListener(\"click\", this.onClickOfClose.bind(this));\n\n        this._tagClose.setAttribute(\"class\", \"closeTag\");\n\n        this._tagElement.append(this._tagContent);\n\n        this._tagElement.appendChild(this._tagClose);\n\n        this._innerContainer.appendChild(this._tagElement);\n\n        this._inputElement.value = \"\";\n\n        this._notifyOutputChanged();\n      }\n    } else return;\n  };\n  /**\r\n  * Function called On click of remove Tag\r\n  */\n\n\n  MultiTag.prototype.onClickOfClose = function (e) {\n    this._taggedValues.splice(this._taggedValues.indexOf(e.target.previousSibling.textContent), 1);\n\n    e.target.parentElement.remove();\n\n    if (this._taggedValues.length && this._innerContainer.classList.contains(\"hideBlock\") && !this._innerContainer.classList.contains(\"displayBlock\")) {\n      this._innerContainer.classList.remove(\"hideBlock\");\n\n      this._innerContainer.classList.add(\"displayBlock\");\n    } else if (!this._taggedValues.length && !this._innerContainer.classList.contains(\"hideBlock\") && this._innerContainer.classList.contains(\"displayBlock\")) {\n      this._innerContainer.classList.remove(\"displayBlock\");\n\n      this._innerContainer.classList.add(\"hideBlock\");\n    }\n\n    this._notifyOutputChanged();\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  MultiTag.prototype.updateView = function (context) {\n    // @ts-ignore \n    Xrm.Page.getAttribute(this._tagValueFieldName).setValue(this._taggedValues.join(\", \"));\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  MultiTag.prototype.getOutputs = function () {\n    var result = {\n      TagValue: this._taggedValues.join(\", \")\n    };\n    return result;\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  MultiTag.prototype.destroy = function () {\n    this._inputElement.removeEventListener(\"keypress\", this.onKeyPress);\n\n    this._tagClose.removeEventListener(\"click\", this.onClickOfClose);\n  };\n\n  return MultiTag;\n}();\n\nexports.MultiTag = MultiTag;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./MultiTag/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('MultiTagControl.MultiTag', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MultiTag);
} else {
	var MultiTagControl = MultiTagControl || {};
	MultiTagControl.MultiTag = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.MultiTag;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}